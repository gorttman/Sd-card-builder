#!/bin/bash
sed -i 's/^#\(.*ansible.*\)/\1/' /etc/crontab
systemctl restart cron
