#!/bin/bash
echo "Mounting NFS shares..."
mount -a
